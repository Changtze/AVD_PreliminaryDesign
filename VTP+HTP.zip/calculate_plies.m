function [n_axial, n_shear] = calculate_plies(M, V, varargin)
    % Inputs:
    % M = Bending moment (Nm)
    % V = Shear force (N)
    % Optional inputs (name-value pairs):
    % 'sigma_axial' = Allowable axial stress (Pa) - Default: 500e6 (AS4/ETK8 typical)
    % 'tau_shear' = Allowable shear stress (Pa) - Default: 150e6 (AS4/ETK8 typical)
    % 't_ply' = Ply thickness (m) - Default: 0.13716e-3
    % 'spar_height' = Spar height (m) - Default: 0.3 (assumed)
    % 'spar_width' = Spar width (m) - Default: 0.1 (assumed)
    p = inputParser;
    addParameter(p, 'sigma_axial', convpres(300e3,'psi','pa') , @isnumeric);    % axial strength (Pa)
    addParameter(p, 'tau_shear', convpres(15e3,'psi','pa'), @isnumeric);       % shear strength (Pa)
    addParameter(p, 't_ply', 0.13716e-3, @isnumeric);      % ply thickness (m)
    addParameter(p, 'spar_height', 0.4524, @isnumeric);       % Spar height (m)
    addParameter(p, 'spar_width', 3.7698, @isnumeric);       % Spar width (m)
    parse(p, varargin{:});  % incase input given, else take defaults
    
    % extract variables
    sigma_axial = p.Results.sigma_axial;
    tau_shear = p.Results.tau_shear;
    t_ply = p.Results.t_ply;
    h = p.Results.spar_height;
    w = p.Results.spar_width;
    

    ts = 15e-3; % thickness of spar (m)
    % Calculate required plies based on bending moment (axial plies)
    % Axial stress formula: sigma = M * y / I, simplified for spar as a beam
    I = 2*(h/2)^2 + 2*(h^3 / 12)*(ts);              % Second moment of area
    axial_force = M * (h/2) / I;   % Max force at spar's top/bottom
    n_axial = ceil(axial_force / (sigma_axial * t_ply * w));
    
    % Calculate required plies based on shear force (shear plies)
    % Shear stress formula: tau = V / (h * w)
    shear_force = V / (h * w);     % Average shear stress
    n_shear = ceil(shear_force / (tau_shear * t_ply));
    
    % Apply 70% shear ply rule (Lockheed Martin's guideline)
    total_plies = n_axial + n_shear;
    if n_shear / total_plies < 0.7
        % Adjust to ensure shear plies >= 70% of total
        n_shear = ceil(0.7 / 0.3 * n_axial);
        total_plies = n_axial + n_shear;
    end
    
    % Ensure symmetry (even number of plies)
    if mod(n_axial, 2) ~= 0
        n_axial = n_axial + 1;     % Round up to even number
    end
    if mod(n_shear, 2) ~= 0
        n_shear = n_shear + 1;     % Round up to even number
    end
    
    % Display results
    fprintf('Axial plies (0/90°): %d\n', n_axial);
    fprintf('Shear plies (±45°): %d\n', n_shear);
    fprintf('Total plies: %d (Shear = %.1f%%)\n', ...
            n_axial + n_shear, 100 * n_shear / (n_axial + n_shear));
end