%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%   EMPENNAGE PRELIM CALC   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Calculating AC coordinates for HT
clear;
clc;

% Input parameters
S_ht = 106.3;      % Horizontal tail area [m²]
taper_ratio = 0.35; % Taper ratio [-]
aspect_ratio = 4;   % Aspect ratio [-]
sweep_angle = 36;   % Leading edge sweep angle [deg]

% Calculate derived parameters
bh = sqrt(S_ht * aspect_ratio);          % Span m
c_root = (2 * S_ht) / (bh * (1 + taper_ratio));  %Root chord m
c_tip = taper_ratio * c_root;           % Tip chord m

% Generate spanwise coordinates (half-span)
y = linspace(0, bh/2, 50);  % Only need to model half the wing

% Leading edge (x) and chord distribution (c) for half-span
x_le = y * tand(sweep_angle);    
c = c_root * (1 - (1 - taper_ratio) * (y / (bh/2))); 

x_te = x_le + c;


x_offset = -x_te(1); % Adjust so trailing edge of root chord starts at 0
x_le = x_le + x_offset;
x_te = x_te + x_offset;

% Calculate MAC (Mean Aerodynamic Chord) and its spanwise position
MAC_length = (2/3) * c_root * (1 + taper_ratio + taper_ratio^2) / (1 + taper_ratio);
y_MAC = (bh / 6) * (1 + 2 * taper_ratio) / (1 + taper_ratio); % MAC position from root

% Aerodynamic Center (25% of MAC from leading edge at y_MAC)
x_le_MAC = y_MAC * tand(sweep_angle) + x_offset; % Leading edge of MAC
x_ac1 = x_le_MAC + 0.25 * MAC_length; % AC position

x_ac_h = x_ac1 + c_root; % x positon from start of horizontal tailplane of AC

%% Calculating AC coordinates for wings

% Input parameters
S_w = 438.288;      % Horizontal tail area [m²]
taper_ratio = 0.25; % Taper ratio [-]
aspect_ratio = 9.2;   % Aspect ratio [-]
sweep_angle = 31.6696;   % Leading edge sweep angle [deg]

% Calculate derived parameters
bw = sqrt(S_w * aspect_ratio);          % Span [m]
c_root = (2 * S_w) / (bw * (1 + taper_ratio));  % Root chord [m]
c_tip = taper_ratio * c_root;           % Tip chord [m]

% Generate spanwise coordinates (half-span)
y = linspace(0, bw/2, 50);  % Only need to model half the wing, use symmetry

% Leading edge (x) and chord distribution (c) for half-span
x_le = y * tand(sweep_angle);     % Leading edge x-coordinate
c = c_root * (1 - (1 - taper_ratio) * (y / (bw/2))); % Chord at y

% Trailing edge x-coordinate
x_te = x_le + c;

% Adjust to make the root chord start at (0, 0)
x_offset = -x_te(1); % Adjust so trailing edge of root chord starts at 0
x_le = x_le + x_offset;
x_te = x_te + x_offset;

% Calculate MAC (Mean Aerodynamic Chord) and its spanwise position
MAC_length = (2/3) * c_root * (1 + taper_ratio + taper_ratio^2) / (1 + taper_ratio);
y_MAC = (bw / 6) * (1 + 2 * taper_ratio) / (1 + taper_ratio); % MAC position from root

% Aerodynamic Center (25% of MAC from leading edge at y_MAC)
x_le_MAC = y_MAC * tand(sweep_angle) + x_offset; % Leading edge of MAC
x_ac2 = x_le_MAC + 0.25 * MAC_length; % AC position

x_ac_w = x_ac2 + c_root; % AC coordinate from start of wing



%% Moment Equillibrium to find total lift on tail

% First we need to calculate the moment arm lengths

xCG = 37.41; % Distance from nose to CG of plane (m)
HT_pos = 63; % Horizontal Tailplane position from nose to start of HT (m)
W_pos = 26; % Wing position from nose to start of wing (m)

lw = xCG - (W_pos + x_ac_w); % Moment arm for lift produced by Wing
lh = (HT_pos + x_ac_h) - xCG; % Moment arm for lift produced by HT

% Now we need to do a moment balance

MTOW = 3324454.35; % Maximum takeoff weight of the aircraft (N)

Liftw = MTOW;
Lifth = (lw/lh) * Liftw;

% Finding different cases

% initialising parameters


rho0 = 1.225; % sealevel density
alt = convlength(39000, 'ft', 'm');
[T, a, P, rho] = atmosisa(alt);

% Finding Tail Lift array

odyfile = load("static_stability.mat")
xcg_array = odyfile.stability.region.xcg; % (takeoff/landing/cruise_start/cruise_end)
lw_array = xcg_array - (W_pos + x_ac_w); % Moment arm for lift produced by Wing
lh_array = (HT_pos + x_ac_h) - xcg_array; % Moment arm for lift produced by HT
MTOW = 3324454.35; % Maximum takeoff weight of the aircraft (N)

n = [2.5; -1; 3.75]; % load factors Va Va Vd
Liftw_array = MTOW;
Lifth_array = abs((lw_array./lh_array) .* MTOW);

% Case 1: full fuel Case 2: no fuel
Lifth_cases = [Lifth Lifth_array(2)];

Lifth_ff = Lifth_cases(1) *n; % Va Va Vd at full fuel
Lifth_nf = Lifth_cases(2) *n; % Va Va Vd at no fuel
Lifth = [Lifth_ff, Lifth_nf]; 



%% Now to find the lift distribution of the tail

Lift_cases = Lifth;
% Spanwise position and discretization for HT
s = bh/2;  % Half-span
dm = 0.1;  % Distance between mass stations
m_stations = linspace(0, s, s/dm + 1);  % Discretizing mass stations
L0 = Lift_cases ./ (pi * s);  % Scaling factor for elliptical lift distribution

% Preallocate arrays for Lift, Shear Force (SF), Bending Moment (BM), and differential moments (dM)
dL = zeros(length(m_stations), numel(Lift_cases));
SF = zeros(size(dL));
BM = zeros(size(dL));
Lift = zeros(size(dL));
dM = zeros(size(dL));

for j = 1:numel(Lift_cases)
    for i = 1:length(m_stations)
        % Elliptical lift distribution for each case
        dL(i, j) = sqrt(1 - (m_stations(i)/s)^2) * L0(j);
        if i < length(m_stations)
            Lift(i, j) = 0.5*(dL(i, j)+dL(i+1, j))*(m_stations(i+1)-m_stations(i));
        else
            Lift(i, j) = 0;  % Ensuring the last element is zero
        end
    end
    % Calculating Shear Force from cumulative sum of Lift
    for i = 1:length(m_stations)
        SF(i, j) = sum(Lift(i:end, j));
    end
    % Calculating differential bending moments
    for i = 1:length(m_stations)
        if i < length(m_stations)
            dM(i, j) = 0.5*(SF(i, j)+SF(i+1, j))*(m_stations(i+1)-m_stations(i));
        else
            dM(i, j) = 0;  % Ensuring the last element is zero
        end
    end
    % Calculating total bending moments from cumulative sum of dM
    for i = 1:length(m_stations)
        BM(i, j) = sum(dM(i:end, j));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%% CALCULATING TORQUE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Calculating Pitching Moment

 % Summing total Lift
% AOA

Clmax = 1.4 ; % CL max

Cla2D = 4.5089 ; % 1/rad

ARh = 4;

Cla = (ARh/(ARh+3))*Cla2D;


aoa = (Clmax*0.8) / Cla2D ; % Finding Angle of Attack (rad)
% Pitching Moment calculator 


Cma = 0.13 + 0.8 * S_ht * Cla * (-lh/ MAC_length) / S_w; % per rad

VauEAS = 148.2; % m/s EAS of ultimate maneuvre vel

Vau = sqrt(rho0/rho) * VauEAS; % converting to TAS

M_0 = (aoa * Cma) * S_ht * MAC_length * 0.5 * 1.225 * Vau^2;

totalLift = zeros(1, size(Lift, 2));  % To store the total lift for each case
Liftnew = zeros(size(Lift));  % To store the normalized lift values
dpM = zeros(size(Lift));  % To store the product of M_0 and normalized lift values
nn = [n n];

for j = 1:numel(totalLift)
    totalLift(j) = sum(Lift(:,j));% Summing up all rows in each column


end
% Calculate total lift for each case
for j = 1:numel(totalLift)
    % Normalize lift values and calculate dpM
    for i = 1:length(m_stations)  % Loop over all stations
        Liftnew(i,j) = Lift(i,j) / (2 * abs(totalLift(2)) * 0.1);  % Normalizing lift
        dpM(i,j) = M_0 * Liftnew(i,j);  % Assuming M_0 is a scalar, modify if it's an array
    end
end



for j = 1:numel(Lift_cases)
    % Calculating differential bending moments
    for i = 1:length(m_stations)
        if i < length(m_stations)
            pM(i, j) = 0.5*(dpM(i, j)+dpM(i+1, j))*(m_stations(i+1)-m_stations(i));
        else
            pM(i, j) = 0;  % Ensuring the last element is zero
        end
    end
end

cM = dM + pM; % combined moment = lift moment + pitching moment
[var1, var2] = size(dM);
Ti = zeros([var1 var2]); % Torque integrated

for j = 1:numel(Lift_cases)
    for i = 1:length(m_stations)
        Ti(i, j) = 0.003* sum(cM(i:end, j));
    end
end




% Set default properties for text interpretation and line width globally
set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 15);
set(0, 'DefaultLineLineWidth', 1.5);

% Color for each case
colors = ['k', 'b', 'r', 'g', 'm', 'c'];

% Plot labels and titles
plot_titles = {'Lift Distribution', 'Shear Force Distribution', 'Bending Moment Distribution', 'Torque Distribution'};
y_labels = {'Lift (N/m)', 'Shear Force (N)', 'Bending Moment (Nm)', 'Torque (Nm)'};

for k = 1:4
    figure; % Create new figure for each load type
    hold on; % Allow multiple lines on same plot
    
    % Plot all cases for this load type
    for j = 1:numel(Lift_cases)
        switch k
            case 1
                plot(m_stations, dL(:, j), 'Color', colors(j));
            case 2
                plot(m_stations, SF(:, j), 'Color', colors(j));
            case 3
                plot(m_stations, BM(:, j), 'Color', colors(j));
            case 4
                plot(m_stations, Ti(:, j), 'Color', colors(j));
        end
    end
    
    % Add figure formatting (common to all cases)
    xlabel('Spanwise position (m)', 'Interpreter', 'latex');
    ylabel(y_labels{k}, 'Interpreter', 'latex');
    legend('Va, n = 2.5 Full Fuel', 'Va, n = -1 Full Fuel', 'Vd, n = 3.75 Full Fuel',...
           'Va, n = 2.5 No Fuel', 'Va, n = -1 No Fuel', 'Vd, n = 3.75 No Fuel',...
           'Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    grid minor;
    hold off; % Release figure for next plot
end

% Reset default properties to avoid affecting other scripts or functions
set(0, 'DefaultTextInterpreter', 'remove');
set(0, 'DefaultAxesFontSize', 'remove');
set(0, 'DefaultLineLineWidth', 'remove');
















