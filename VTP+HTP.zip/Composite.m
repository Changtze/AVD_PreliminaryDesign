
%%%%%%%%%%%%%%%%%%%% COMPOSITE MATERIALS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;
% Material properties

sigma_xx = convpres(550000,'psi','pa'); % ultimate tensile stress
sigma_xy = convpres(15000,'psi','pa'); % ultimate shear stress

% Calculating tail load

altitudef = 28000;
altitude = convlength(altitudef,'ft','m'); %cruise alt
[T, a, P, rho] = atmosisa(altitude);
rho_0 = 1.225; % sea level rho
Vinf = 146; %Design cruise speed ms-1
b = 60.2414; % wingspan
s = b/2; %semi span
xCG = 37.41;


lT = 0.3 * s; % Spanwise distance of engine from datum line
lV = (58.05 + 8.7862)-xCG; % distance from cg to vertical tailplane MAC
T = 454.83e3; % engine thrust N

% IdealClaT = 4.352; % ideal lift curve slope of tail
% k = 0.9; % Constant accounting for losses in tail
% RealClaT = IdealClaT * k; % Real " "

% Initialising important variables

Sv = 61.6; % Tailplane Sref
Sref = 438.288; % Wing Sref
qv = 0.5 * rho_0 * Vinf^2;
qw = 0.5 * rho_0 * Vinf^2;
Nuv = qv/qw ; %Aerodynamic Efficiency of tailplane
ClBeta = 2.3618; % Coefficent of lift due to a sideslip angle

effClRatio = 0.85; % Cldelta/Cl theory from DATCOM- Empennage Sizing
Cldeltheory = 4.75; % Cldelta theory from DATCOM - Empennage Sizing
Kprime = 0.65; % Kprime also from DATCOM - Empennage Sizing
defRd = 25; % Max deflection of rudder in degrees 
defR = deg2rad(25); % " " in degrees
delcl = defR * effClRatio * Cldeltheory * Kprime; % Change in CL due to rudder deflection
Sv = 11.1416; % Swet of ref

Cltail = ClBeta + delcl;

% Moments

Fv = (lT/lV) * T;
Beta = Fv /((qv)*Sv*Cltail);
Betad = rad2deg(Beta);

rf = 3.1309; % fuselage radius m
Macy = 4.2547; % MAC y coordinate
Tf = Fv* (rf+ Macy ); % Torque on fuselage
Mf = Fv * (lV);
Af = pi *rf^2; % Cross sectional area of fuselage
t = 2e-3; % Skin thickness asummed to be 2mm
tau = Tf/(2*Af*t)


disp(['Torque subjected on fuselage due to OEI = ', num2str(Tf), ' Nm']);
disp(['Bending Moment subjected on fuselage due to OEI = ', num2str(Mf), ' Nm']);
disp(['Sideslip at Steady-State OEI = ', num2str(Betad), ' degrees']);
disp(['Shear stress at Steady-State OEI = ', num2str(tau), ' Pa']);
disp(['Force on tailplane at Steady-State OEI = ', num2str(Fv), ' N']);


%Initialising Parmameters

b = sqrt(1.6*Sv); % wingspan (m)
s = b; % half span (m)
L0 = Fv *2 /(pi*s); % using integral of elliptical lift distribution
rf = 3.1309; % Fuselage outerbound radius (m)

% Implementing Elliptical Distribution Assumption
Lift_dist = @(y) L0*sqrt(1-(y./s).^2);
dm = 0.01; %Distance between mass stations
m_stations = linspace(0,s,s/dm); % discretising mass stations


% Chord distribution parameters

Vtaper = 0.4; % vertical tailplane taper ratio
VrootC = (2 * Sv) / (s * (1 + Vtaper));  % vertical tailplane root chord
chordDist = @(y) VrootC .* (1 - (1 - Vtaper) .* (2*y ./ b)); % Vertical tailplane chord distribution
Lift_moment_arm = 0.2 .* chordDist(m_stations);



% Calculating Lift distribution for our wing
[m,n] = size(m_stations);
dL = Lift_dist(m_stations); % Finding lift distribution values at mass stations


%Simplifying the variables (not really necessary)
y = m_stations;

%Trapezium rule to find the sectional lift from the Lift Distribution


for i = 1:n
    if i == n
        Lift(i) = 0;
    else
        Lift(i) = 0.5*(dL(i)+dL(i+1))*(y(i+1)-y(i));
    end
end

%Finding Shear Force

for i = 1:n
    SF(i) = sum(Lift(i:end));
end

%Finding Sectional bending moment

dM = zeros(n);

for i = 1:n
    if i == n
        dM(i) = 0;
    else
        dM(i) = 0.5*(SF(i)+SF(i+1))*(y(i+1)-y(i));
    end
end

%Finding bending moment

for i = 1:n
    BM(i) = sum(dM(i:end));
end

dT = 10 + Lift_moment_arm .* Lift ;

for i = 1:n
    Torque(i) = sum(dT(i:end));
end



% Set default properties for text interpretation and line width globally
set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 15);
set(0, 'DefaultLineLineWidth', 1.5);
set(0, 'DefaultAxesLineWidth', 1.5); % Set axis line width

% Plot for Lift Distribution
figure;
plot(y, Lift, 'LineWidth', 2, 'Color', 'k');
hold on;
plot(y, -Lift, 'LineWidth', 2, 'Color', 'k');
title('Lift Distribution');
xlabel('Spanwise position (m)');
ylabel('Lift Distribution (N/m)');
grid on; % Major grid
grid minor; % Minor grid
hold off;

% Plot for Shear Force Distribution
figure;
plot(y, SF, 'LineWidth', 2, 'Color', 'k');
hold on;
plot(y, -SF, 'LineWidth', 2, 'Color', 'k');
xlabel('Spanwise position (m)','FontSize', 25);
ylabel('Shear Force (N)','FontSize', 25);
grid on; % Major grid
grid minor; % Minor grid
hold off;

% Plot for Bending Moment Distribution
figure;
plot(y, BM, 'LineWidth', 2, 'Color', 'k');
hold on;
plot(y, -BM, 'LineWidth', 2, 'Color', 'k');
xlabel('Spanwise position (m)','FontSize', 25);
ylabel('Bending Moment (Nm)','FontSize', 25);
grid on; % Major grid
grid minor; % Minor grid
hold off;

% Plot for Torque Distribution
figure;
plot(y, Torque, 'LineWidth', 2, 'Color', 'k');
hold on;
plot(y, -Torque, 'LineWidth', 2, 'Color', 'k');
xlabel('Spanwise position (m)','FontSize', 25);
ylabel('Torque (Nm)','FontSize', 25);
grid on; % Major grid
grid minor; % Minor grid
hold off;

% Reset default properties to avoid affecting other scripts or functions
set(0, 'DefaultTextInterpreter', 'remove');
set(0, 'DefaultAxesFontSize', 'remove');
set(0, 'DefaultLineLineWidth', 'remove');
set(0, 'DefaultAxesLineWidth', 'remove');

SF_max = SF(1);
BM_max = BM(1);

h_box = 0.12 * VrootC; % wing box height
t_ply = 0.13716e-3; % ply thickness m
Nx = BM_max / (VrootC * h_box); % compressive loads
Nt = 10 * Nx / (0.8*sigma_xx * t_ply); % number of tensile components 0.8 - compressive assumption
Ns = SF_max / (sigma_xy * t_ply * h_box * 2) ; % number of shear components


disp(['Number of tensile components : ', num2str(ceil(Nt))]);

disp(['Number of shear components : ', num2str(ceil(Ns))]);

% Define material properties in SI units (Pascals and meters)
E1 = 34e6 * 6894.76;       % Longitudinal modulus (Pa) [34e6 psi → Pa]
E2 = 1.1e6 * 6894.76;      % Transverse modulus (Pa)
nu12 = 0.3;                % Major Poisson's ratio
G12 = 0.5e6 * 6894.76;     % In-plane shear modulus (Pa)
t_ply = 0.0054 * 0.0254;   % Ply thickness (meters) [0.0054 inches → m]

% Define stacking sequence (angles in degrees)
angles = [0, 90, 45, -45, 90, 0, -45, -45, 0, 90, -45, 45, 90, 0];     % Example: [0°, 45°, -45°, 90°]

% Number of plies
n_plies = length(angles);

% Calculate Q matrix for a unidirectional ply
Q11 = E1 / (1 - nu12^2 * (E2/E1));
Q22 = E2 / (1 - nu12^2 * (E2/E1));
Q12 = nu12 * E2 / (1 - nu12^2 * (E2/E1));
Q66 = G12;

Q = [Q11, Q12, 0;
     Q12, Q22, 0;
     0,    0,   Q66];

% Initialize ABD matrices
A = zeros(3, 3);
B = zeros(3, 3);
D = zeros(3, 3);

% Calculate ABD matrices
for k = 1:n_plies
    theta = angles(k);          % Ply angle in degrees
    theta_rad = theta * pi/180; % Convert to radians
    
    % Transformation matrix
    m = cos(theta_rad);
    n = sin(theta_rad);
    T = [m^2, n^2, 2*m*n;
         n^2, m^2, -2*m*n;
         -m*n, m*n, m^2 - n^2];
    
    % Transformed reduced stiffness matrix
    Qbar = T' * Q * T;
    
    % Ply position (mid-plane as reference, in meters)
    z_k = (k - n_plies/2 - 0.5) * t_ply;
    z_k_1 = (k - n_plies/2 - 1.5) * t_ply;
    
    % Update ABD matrices
    A = A + Qbar * (z_k - z_k_1);
    B = B + 0.5 * Qbar * (z_k^2 - z_k_1^2);
    D = D + (1/3) * Qbar * (z_k^3 - z_k_1^3);
end

% Extract D submatrix components (units: Pa·m³)
D11 = D(1, 1);
D22 = D(2, 2);
D12 = D(1, 2);
D66 = D(3, 3);

% Display D matrix components
fprintf('D11 = %.2e Pa·m³\n', D11);
fprintf('D22 = %.2e Pa·m³\n', D22);
fprintf('D12 = %.2e Pa·m³\n', D12);
fprintf('D66 = %.2e Pa·m³\n', D66);

% Calculate buckling load (a and b in meters)
a = 9.9;       % Spar length (vertical tailplane span, meters)
b = 0.3 * VrootC;     % Spar panel width (rib spacing, meters)

Nx_cr = (pi^2 / b^2) * 2 * ((D11 * D22)^0.5 + D12 + 2*D66);
fprintf('Critical Buckling Load (Nx_cr) = %.2f N/m\n', 20 * Nx_cr);

Ratio_1 = Nx/(Nx_cr*20);
fprintf('Ratio = %.2f ', Ratio_1);
%% MAC Y POSITION CODE

S_v = 61.6;          % VT reference area [m²]
taperRatio = 0.4;    % VT taper ratio (tipChord/rootChord)
AR_v = 1.6;          % VT aspect ratio
sweepAngle = 41.2;   % VT leading-edge sweep angle [deg]

% Derived geometry calculations
span = sqrt(AR_v * S_v);              % Span (height) of the stabilizer
rootChord = (2 * S_v) / (span * (1 + taperRatio));  % Root chord
tipChord = rootChord * taperRatio;    % Tip chord
macLength = (2/3) * rootChord * (1 + taperRatio + taperRatio^2) / (1 + taperRatio); % MAC length
macYPosition = (span/3) * (1 + 2*taperRatio) / (1 + taperRatio); % Spanwise MAC position
%%

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% MECHANICAL PROPERTIES DECLARATION

        %(Glass-VE)
         El = convpres(19.3,'psi','pa')      ;   % [ MPA ]
         Et = convpres(1.23,'psi','pa')       ;   % [ MPA ]
        Glt = convpres(0.73,'psi','pa')       ;   % [ MPA ]
        vlt = 0.32     ;   % [ MPA ]
        vtl = vlt*(Et/El);   % [ MPA ]
        
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  

% LAYER ORIENTATION
% 

orientations = [0, 90, -45, 90, 0, -45, -45, 0, 90, -45, 90, 0]; % [ ° ]
% first iteration

layers = length(orientations); % number of layers

thickness = 0.13716 ; % [ mm ]

% ------------------------------------------------------------------
% Calculations of [S]  &   [Q] matrix in principal axes
s11=1/El;   s12=-vtl/Et;    s21=-vlt/El;    s22=1/Et;   s66=1/Glt;

Slt=[s11    s12     0;
     s21    s22     0;
     0      0       s66];
 
Qlt = inv(Slt);

q11 = Qlt(1,1);     q12 = Qlt(1,2);     q13 = Qlt(1,3);
q21 = Qlt(2,1);     q22 = Qlt(2,2);     q23 = Qlt(2,3);
q31 = Qlt(3,1);     q32 = Qlt(3,2);     q33 = Qlt(3,3);

% -------------------------------------------------------------------
h = zeros (layers+1);
h(layers+1) = layers*thickness/2; 
qbarK = zeros(3*layers,3);

for k = 1 : layers % Transformation of the reduced stiffness matrix
    c = cosd(orientations(k));
    s = sind(orientations(k));
    
    qactual = zeros(3,3); % Reduced stiffness matriz of the layer number 'k'
    
    qactual(1,1) = q11*c^4+q22*s^4+s*c*(s*c*(q21+q12+4*q33)+c^2*(2*q31+2*q13)+s^2*(2*q32+2*q23));
    qactual(1,2) = q12*c^4+q21*s^4+s*c*(s*c*(q11+q22-4*q33)+c^2*(2*q32-2*q13)+s^2*(2*q31-2*q23));
    qactual(1,3) = s*c*(s*c*(-2*q31+2*q32)+c^2*(-q11+q12)+s^2*(-q21+q22))+(c^2-s^2)*(q13*c^2+q23*s^2+2*q33*s*c);
    qactual(2,1) = q21*c^4+q12*s^4+s*c*(s*c*(q11+q22-4*q33)+c^2*(-2*q31+2*q23)+s^2*(-2*q32+2*q13));
    qactual(2,2) = q22*c^4+q11*s^4+s*c*(s*c*(q21+q12+4*q33)+c^2*(-2*q32-2*q23)+s^2*(-2*q31-2*q13));
    qactual(2,3) = s*c*(s*c*(2*q31-2*q32)+c^2*(-q21+q22)+s^2*(-q11+q12))+(c^2-s^2)*(q13*s^2+q23*c^2-2*q33*s*c);
    qactual(3,1) = s*c*(s*c*(-2*q13+2*q23)+c^2*(-q11+q21)+s^2*(-q12+q22)+2*q33*(c^2-s^2))+(c^2-s^2)*(q31*c^2+q32*s^2);
    qactual(3,2) = s*c*(s*c*(2*q13-2*q23)+c^2*(-q12+q22)+s^2*(-q11+q21)-2*q33*(c^2-s^2))+(c^2-s^2)*(q31*s^2+q32*c^2);
    qactual(3,3) = s*c*(s*c*(q11-q21-q12+q22)+(c^2-s^2)*(-q31+q32-q13+q23))+q33*(c^2-s^2)^2;
   
    qbarK([3*k-2:3*k],[1:3])=qactual([1:3],[1:3]); % Kepts the actual reduced stiffness matrix
    h(k)=(k-layers/2-1)*thickness; % Layer position

end
A = zeros(3);   B = zeros(3);   D = zeros(3);

for i=1:3 % Sum of the products (Qij)[z(k)²-z(k-1)²] cycle
    for j=1:3
            qactual([1:3],[1:3])=qbarK([1:3],[1:3]);
            A(i,j) = qactual(i,j) * (h(2) - h(1));
            B(i,j) = 1/2*(qactual(i,j) * (h(2)^2 - h(1)^2));
            D(i,j) = 1/3*(qactual(i,j) * (h(2)^3 - h(1)^3));
            
         for k = 2 : layers
            qactual([1:3],[1:3]) = qbarK( [3*k-2:3*k] , [1:3] );
            A(i,j) = qactual(i,j) * (h(k+1) - h(k)) + A(i,j);
            B(i,j) = 1/2*(qactual(i,j) * (h(k+1)^2 - h(k)^2)) + B(i,j);
            D(i,j) = 1/3*(qactual(i,j) * (h(k+1)^3 - h(k)^3)) + D(i,j);    
         end
    end
end

ask2usr = input('Want to display isolated A, B, D matrices? (y/n)  ','s');
if ask2usr =='y'
    disp(' ');
    disp('  DONE (☞ﾟ∀ﾟ)☞');
    A
    B
    D
else
    disp(' ');
    disp('  DONE (☞ﾟ∀ﾟ)☞');disp(' ');
end

disp('_____________________________________________________________________________________________'); disp(' ');  
ABD = [A,B;B,D]
disp('_____________________________________________________________________________________________'); disp(' ');               
abd = inv(ABD)
disp('_____________________________________________________________________________________________'); disp(' ');  
disp(' ');
D11 = D(1, 1);
D22 = D(2, 2);
D12 = D(1, 2);
D66 = D(3, 3);


fprintf('D11 = %.2e Pa·m³\n', D11);
fprintf('D22 = %.2e Pa·m³\n', D22);
fprintf('D12 = %.2e Pa·m³\n', D12);
fprintf('D66 = %.2e Pa·m³\n', D66);


a = 9.9;       % Spar length (vertical tailplane span, meters)
b = 0.3 *VrootC;     % Spar panel width (rib spacing, meters)

Nx_cr = (pi^2 / b^2) * 2 * ((D11 * D22)^0.5 + D12 + 2*D66);
fprintf('Critical Buckling Load (Nx_cr) = %.2f N/m\n', Nx_cr);
Ratio_1 = Nx/(Nx_cr);
fprintf('Ratio = %.2f ', Ratio_1);


hc = 0:1:25;  % From 12mm to 25mm in 1mm increments

% Define ply orientations in degrees and convert to radians
theta_deg = [-45, 0, 45, 90];
theta_rad = deg2rad(theta_deg);



Gc = 310.3e6; % shear modulus of the core material pa

hc_m = hc / 1000;

% Prepare a figure for plotting
figure;
hold on;
xlabel('Core height hc (mm)');
ylabel('Critical load N_{cr} (N/m)');

grid on;

% Colors for each ply orientation plot
colors = ['r', 'g', 'b', 'k'];  % Red, Green, Blue, Black for each angle

set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 20);
set(0, 'DefaultLineLineWidth', 1.5);
set(0, 'DefaultAxesLineWidth', 1.5); % Set axis line width
% Loop through each angle
for j = 1:length(theta_rad)
    theta = theta_rad(j);
    Ncr = zeros(size(hc));  % Initialize Ncr for each orientation

    % Calculate Ncr for each value of hc
    for i = 1:length(hc_m)
        Ncr(i) = (pi^2/b^2 ) * (D11*D22) / (D11 * sin(theta)^4 + D22 * cos(theta)^4) * ...
                 (1 +  (pi^2 * D11) / (b^2 * Gc * hc_m(i)))^(-1);
    end

    % Plot the results for each orientation
    plot(hc, Ncr, '-o', 'Color', colors(j), 'DisplayName', sprintf('\\theta = %d^\\circ', theta_deg(j)),'LineWidth', 2);
end
legend show; % Display the legend
grid on; % Enable grid
grid minor; % Enable minor grid lines
xlabel('Core height $h_c$ (mm)', 'Interpreter', 'latex','FontSize', 20); % Label x-axis
ylabel('Critical load $N_{cr}$ (N/m)', 'Interpreter', 'latex','FontSize', 20); % Label y-axis
% Set default properties for text interpretation, line width, and font size globally




Ncr_1 = (pi^2/b^2 ) * (D11*D22) / (D11 * sind(45)^4 + D22 * cosd(45)^4) * ...
         (1 +  (pi^2 * D11) / (b^2 * Gc * 20e-3))^(-1);
Ncr_2 = (pi^2/b^2 ) * (D11*D22) / (D11 * sind(0)^4 + D22 * cosd(0)^4) * ...
         (1 +  (pi^2 * D11) / (b^2 * Gc * 20e-3))^(-1);
Ncr_3 = (pi^2/b^2 ) * (D11*D22) / (D11 * sind(90)^4 + D22 * cosd(90)^4) * ...
         (1 +  (pi^2 * D11) / (b^2 * Gc * 20e-3))^(-1);
Ncr__1 = ( Ncr_1 + Ncr_2 + Ncr_3 ) /3;

Ratio_1 = Nx/(Ncr_3);
fprintf('Ratio = %.2f ', Ratio_1);

% Add a legend
legend show;
hold off;
