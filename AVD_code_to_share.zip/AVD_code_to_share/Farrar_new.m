function [F] = Farrar_new(As_bt_ratio,ts_t_ratio)
%FARRAR Summary of this function goes here

switch ts_t_ratio
case 0.5
data0_5(:,1) = [0.18 0.24 0.29 0.37 0.47 0.83 1.27]';
data0_5(:,2) = [0.5 0.6 0.7 0.75 0.8 0.8 0.75]';
F = interp1(data0_5(:,1),data0_5(:,2),As_bt_ratio,'linear','extrap');
case 0.6
data0_6(:,1) = [0.2 0.27 0.33 0.4 0.48 0.61 0.69 1.3]';
data0_6(:,2) = [0.5 0.6 0.7 0.75 0.8 0.85 0.85 0.8]';
F = interp1(data0_6(:,1),data0_6(:,2),As_bt_ratio,'linear','extrap');
case 0.7
data0_7(:,1) = [0.22 0.3 0.37 0.46 0.54 0.67 0.79 1.16 1.69]';
data0_7(:,2)= [0.5 0.6 0.7 0.75 0.8 0.85 0.88 0.85 0.8]';
F = interp1(data0_7(:,1),data0_7(:,2),As_bt_ratio,'linear','extrap');
case 0.8
data0_8(:,1) = [0.24 0.33 0.42 0.51 0.6 0.74 0.88 1.11 1.52 1.99]';
data0_8(:,2) = [0.5 0.6 0.7 0.75 0.8 0.85 0.9 0.9 0.85 0.8]';
F = interp1(data0_8(:,1),data0_8(:,2),As_bt_ratio,'linear','extrap');
case 0.9
data0_9(:,1) = [0.27 0.36 0.47 0.57 0.66 0.82 0.98 1.46 1.82]';
data0_9(:,2) = [0.5 0.6 0.7 0.75 0.8 0.85 0.9 0.9 0.85]';
F = interp1(data0_9(:,1),data0_9(:,2),As_bt_ratio,'linear','extrap');
case 1
data1(:,1) = [0.28 0.38 0.52 0.63 0.74 0.9 1.11 1.45 1.76]';
data1(:,2) = [0.5 0.6 0.7 0.75 0.8 0.85 0.9 0.95 0.9]';
F = interp1(data1(:,1),data1(:,2),As_bt_ratio,'linear','extrap');
case 1.25
data1_25(:,1) = [0.34 0.48 0.65 0.78 0.94 1.18 1.57 ]';
data1_25(:,2) = [0.5 0.6 0.7 0.75 0.8 0.85 0.9]';
F = interp1(data1_25(:,1),data1_25(:,2),As_bt_ratio,'linear','extrap');
case 1.5
data1_5(:,1) = [0.4 0.55 0.8 0.99 1.23 1.67]';
data1_5(:,2) = [0.5 0.6 0.7 0.75 0.8 0.85]';
F = interp1(data1_5(:,1),data1_5(:,2),As_bt_ratio,'linear','extrap');
case 2
F = NaN;
end
data0_7(:,1) = [0.22 0.3 0.37 0.46 0.54 0.67 0.79 1.16 1.69]';
data0_7(:,2)= [0.5 0.6 0.7 0.75 0.8 0.85 0.88 0.85 0.8];
end
