function [name,component_stations,mass_at_stations] = mass_distribution_area2(name,component_mass,mass_stations,coords,distribution)

% classify type of coordinates
[m,n] = size(coords);

% Compute cross-sectional area at each x location
if (m>1 && n == 1) || (n>1 && m == 1)
    % coordinates refer to lengths of cross sections
    cross_sectional_area = pi * (coords.^2);
    area_sum = trapz(distribution, cross_sectional_area); % Integral of area distribution
elseif m==1 && n==1
    cross_sectional_area = 1;
    area_sum = 1;
else
    % coordinates refer to set of cross sections
    coords_sections = zeros((2/3)*size(coords,1),size(coords,2));
    coords_sections(1:2:end) = coords(1:3:end,:);
    coords_sections(2:2:end) = coords(3:3:end,:);

    cross_sectional_area = zeros(1,size(coords_sections,1)/2);

    for i = 1:size(coords_sections,1)/2
        coords_section = coords([3*i-2,3*i],:);
        cross_sectional_area(i) = polyarea(coords_section(1,:),coords_section(2,:));
    end
    area_sum = trapz(distribution, cross_sectional_area); % Integral of area distribution
end

% Normalize areas to obtain mass distribution
% area_sum = trapz(distribution, cross_sectional_area); % Integral of area distribution
mass_density = (cross_sectional_area / area_sum) * component_mass; % Mass per segment

% Interpolate mass values at desired stations
component_stations =  mass_stations(mass_stations >= min(distribution) & mass_stations <= max(distribution));

% % Option 1 - for calculations
% % ---------------------------------------------------------------------
% if isempty(component_stations)
%     if m==1 && n==1
%     mean_location = distribution;
%     else
%     mean_location = (min(distribution) + max(distribution))/2;
%     end
%     [~,component_idx] = min(abs(mass_stations - mean_location));
%     component_stations = mass_stations(component_idx);
% else
% end


% Option 2 - for plotting
% ---------------------------------------------------------------------
if isempty(component_stations)
    mean_location = (min(distribution) + max(distribution))/2;
    [~,component_idx] = min(abs(mass_stations - mean_location));
    component_stations = mass_stations(component_idx);
else
end



if m ==1 && n==1
    mass_at_stations = mass_density;
else
    mass_at_stations = interp1(distribution, mass_density, component_stations, 'linear', 'extrap');

    % find remainder
    remainder = sum(mass_at_stations) - component_mass;

    % Compute the proportional distribution factor
    proportions = mass_at_stations / sum(mass_at_stations); % Normalize elements

    % Adjust mass at stations by distributing the remainder proportionally
    mass_at_stations_new = mass_at_stations + (-1)*remainder * proportions;

    mass_at_stations = mass_at_stations_new;
end

end