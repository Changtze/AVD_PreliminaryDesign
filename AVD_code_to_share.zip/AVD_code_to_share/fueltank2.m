function [cg,total_volume] = fueltank2(points)
% Define the coordinates of the cuboid


% Compute the convex hull
K = convhull(points(:,1), points(:,2), points(:,3));

% Plot the cuboid
t = trisurf(K, points(:,1), points(:,2), points(:,3), 'FaceColor', 'cyan', 'EdgeColor', 'black','FaceAlpha',0.2);
hold on;
% Mark the vertices
%scatter3(points(:,1), points(:,2), points(:,3), 'filled', 'r');

% Initialize variables for CG calculation
total_volume = 0;
cg = [0, 0, 0];

% Reference point for tetrahedron calculations (arbitrary, e.g., the first vertex)
ref_point = points(1, :);

% Loop through each facet (triangle) in the convex hull
for i = 1:size(K, 1)
    % Get the vertices of the current triangle
    v1 = points(K(i, 1), :);
    v2 = points(K(i, 2), :);
    v3 = points(K(i, 3), :);
    
    % Form a tetrahedron using the reference point and the triangle
    tetra_points = [ref_point; v1; v2; v3];
    
    % Calculate the volume of the tetrahedron
    volume = abs(det([tetra_points'; 1, 1, 1, 1])) / 6;
    
    % Calculate the CG of the tetrahedron
    tetra_cg = mean(tetra_points, 1);
    
    % Accumulate weighted CG and total volume
    cg = cg + tetra_cg * volume;
    total_volume = total_volume + volume;
end

% Final CG by dividing by total volume
cg = cg / total_volume;

% Display the CG on the plot
%scatter3(cg(1), cg(2), cg(3), 100, 'g', 'filled');
%text(cg(1), cg(2), cg(3), ' CG', 'FontSize', 12, 'Color', 'g');

% % Label the axes
% xlabel('X');
% ylabel('Y');
% zlabel('Z');
% title('Non-Right-Angled Cuboid with CG');
% grid on;
% axis equal;

% % Display CG coordinates
% disp('Center of Gravity (CG):');
% disp(cg);
end

