function [window_coords] = window_gen(height, width, edge_radius, position, window_plot)

color = window_plot{1};
line_w = window_plot{2};
line_s = window_plot{3};
name = window_plot{4};

edge_res = 20;

% Corners
t_top_left = linspace(3*pi/2,2*pi,edge_res);
t_top_right = linspace(0,pi/2,edge_res);
t_bot_right = linspace(pi/2,pi,edge_res); 
t_bot_left = linspace(pi,3*pi/2,edge_res);


top_left  = edge_radius*[sin(t_top_left);cos(t_top_left)]   + [-(width/2 - edge_radius);+(height/2 - edge_radius)];
top_right = edge_radius*[sin(t_top_right);cos(t_top_right)] + [+(width/2 - edge_radius);+(height/2 - edge_radius)];
bot_right = edge_radius*[sin(t_bot_right);cos(t_bot_right)] + [+(width/2 - edge_radius);-(height/2 - edge_radius)];
bot_left  = edge_radius*[sin(t_bot_left);cos(t_bot_left)]   + [-(width/2 - edge_radius);-(height/2 - edge_radius)];

window_coords = [top_left,top_right,bot_right,bot_left];
window_coords(end+1,:) = window_coords(2,:);
window_coords(2,:) = 0;

[m,n] = size(position);
if m*n ~= 3
    return
elseif m<n
    position = position';
else
end


window_coords = window_coords + position;
window_coords(:,end+1) = window_coords(:,1);

plot3(window_coords(1,:),window_coords(2,:),window_coords(3,:), Color = color, LineWidth = line_w, LineStyle = line_s,DisplayName = name); hold on
