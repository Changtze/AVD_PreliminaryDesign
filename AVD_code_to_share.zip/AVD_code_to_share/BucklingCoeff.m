function [K] = BucklingCoeff(d_h_ratio, td_ts_ratio, ts_t_ratio, h_b_ratio)
% BUCKLINGCOEFF Interpolates buckling coefficient from ESDU dataset

% Identify the Correct Figure Number from ESDU 71014
if d_h_ratio == 0.3
    if td_ts_ratio == 1
        figNum = "fig_1";
    elseif td_ts_ratio == 2
        figNum = "fig_2";
    end
elseif d_h_ratio == 0.4
    if td_ts_ratio == 1
        figNum = "fig_3";
    elseif td_ts_ratio == 2
        figNum = "fig_4";
    end
elseif d_h_ratio == 0.5
    if td_ts_ratio == 1
        figNum = "fig_5";
    elseif td_ts_ratio == 2
        figNum = "fig_6";
    end
else
    error("Invalid d/h ratio. Must be 0.3, 0.4, or 0.5.");
end

% Determine the Dataset Identifier
switch ts_t_ratio
    case 0.5,  dataNum = "data0_5";
    case 0.6,  dataNum = "data0_6";
    case 0.7,  dataNum = "data0_7";
    case 0.8,  dataNum = "data0_8";
    case 0.9,  dataNum = "data0_9";
    case 1,    dataNum = "data1_0";
    case 1.25, dataNum = "data1_25";
    case 1.5,  dataNum = "data1_5";
    case 2,    dataNum = "data2_0";
    otherwise
        error("Invalid t_s/t ratio. Must be between 0.5 and 2.");
end


load ESDU71014\esdu71014.mat esdu
data = esdu.(figNum).(dataNum); % Load the data from the .mat file

% Interpolate Buckling Coefficient for Given h/b Ratio
K = interp1(data(:,1), data(:,2), h_b_ratio, 'linear', 'extrap');

if isnan(K)
    warning("Interpolation failed for h/b ratio = %.2f. Check data validity.", h_b_ratio);
end

end
