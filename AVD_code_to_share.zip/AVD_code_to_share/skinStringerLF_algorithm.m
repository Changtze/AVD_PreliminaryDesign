%% Fuselage Panel Structural Optimization
% This script evaluates different fuselage panel configurations, selecting optimal
% skin, stringer, and light frame parameters based on geometric and structural constraints.

clear; clc; close all;
load sizing.mat
load fuselage.mat
load shear_bending.mat

%% Aircraft and Material Properties
% These parameters define the structural conditions and constraints

W_aircraft = sizing.M0; % Aircraft weight (kg)
max_BM_f_all = [s(:).max_BM_f]; % Extract maximum bending moment for each load case
max_SF_f_all = [s(:).max_SF_f];
M_max = abs(max_BM_f_all((abs([s(:).max_BM_f]) == max(abs([s(:).max_BM_f]))))) % Maximum bending moment (Nm)
SF_max = abs(max_SF_f_all((abs([s(:).max_SF_f]) == max(abs([s(:).max_SF_f])))))

D_fuselage = 2*fuselage.R;    % Fuselage diameter (m)
C_fuselage = pi * D_fuselage; % Fuselage circumference (m)

E_modulus = 73.85; % Young’s Modulus (GPa)
Et_modulus = E_modulus; % Transverse Young's Modulus (GPa)
L_fuselage = fuselage.afterbody.end_x; % Fuselage length (m)

sigma_yield = 363; % Yield strength (MPa)
rho_material = 2765; % Material density (kg/m^3)
nu = 0.33; % Poisson ratio

%% Compressive Load Estimation
N_load = M_max / (D_fuselage * C_fuselage) % Compressive load per unit length (N/m)

%% Function Handles for Calculations
% These functions define geometric and structural relationships
calc_effective_thickness = @(t_skin, b_panel, A_stringer) t_skin + A_stringer ./ b_panel;
calc_stringer_area = @(h_str, d_str, t_s, t_d) (h_str .* t_s) + (d_str .* t_d);

%% Define Design Variables
% These variables define the range of configurations to evaluate
num_panels = 10:2:200;                      % Number panels
b_panel = (C_fuselage ./ num_panels) * 1000; % Panel width (mm)
h_b_ratios = 0.1:0.1:1;                      % Stringer height-to-panel width ratio
d_h_ratios = [0.3 0.4 0.5];                  % Stringer flange width-to-height ratio

t_s = 1:1:10; % Stringer thickness (mm)
td_ts_ratios = [1 2]; % Flange-to-web thickness ratio
ts_t_ratios = [0.5 0.6 0.7 0.8 0.9 1 1.25 1.5 2]; % Stringer-to-skin thickness ratio

%% Generate Configuration Combinations
configs = combinations(b_panel, h_b_ratios, d_h_ratios, t_s, td_ts_ratios, ts_t_ratios);
disp("Total Possible Configurations: " + height(configs));

%% Compute Geometric Properties
configs.h_str = configs.b_panel .* configs.h_b_ratios;
configs.d_str = configs.h_str .* configs.d_h_ratios;
configs.t_d = configs.t_s .* configs.td_ts_ratios;
configs.t_skin = configs.t_s ./ configs.ts_t_ratios;

configs.num_stringers = (C_fuselage * 1000) ./ configs.b_panel;
configs.A_stringer = calc_stringer_area(configs.h_str, configs.d_str, configs.t_s, configs.t_d);
configs.t_eff = calc_effective_thickness(configs.t_skin, configs.b_panel, configs.A_stringer);

configs.total_area = configs.t_eff .* (C_fuselage * 1000);

%% Shear flow
phi = [flip(linspace(0,2*pi,50)), flip(linspace(pi,2*pi,50))];
r = fuselage.R

% Anticlockwise is positive
Q = SF_max; % Radial Load (N)
P = 0; % Tangential Load (Nm)
T = 0; % Torque (Nm)

Q_Sflow = Q*sin(phi)/(pi*r);
P_Sflow = P*cos(phi)/(pi*r);
T_Sflow = (T + P*r)/(2*pi*r^2);
total_Sflow = (Q_Sflow + P_Sflow + T_Sflow) * 1e-6; % Total shear flow (MPa)

stress_dist_z = cos(phi);
stress_dist_y = sin(phi);
stress_dist = total_Sflow;
stress_dist_vector = [total_Sflow; total_Sflow*0];

q_max = max(stress_dist)*1e6

% Plot Direct stress distribution around the fuselage
figure; hold on; grid on; axis equal
plot3(0*stress_dist_z,stress_dist_y,stress_dist_z,'r', LineWidth = 2, DisplayName="Fuselaeg cross-section")
legend
for i = 1:length(phi)
    if i~=1
        legend(AutoUpdate="off")
    end
    quiver3(0,stress_dist_z(i),stress_dist_y(i),stress_dist(i),0,0,'k', 'LineWidth', 2, 'MaxHeadSize', 1, DisplayName=" Direct stress at each stringer")
end
view(3)
xlabel('Direct stress (MPa)'); ylabel('y'); zlabel('z')
hold off


%% Pressure Loading

[~,~,cabin_alt_pressure,~,~,~] = atmosisa(convlength(8000,'ft','m'))
[~,~,abs_ceil_pressure,~,~,~] = atmosisa(convlength(45000,'ft','m'))

cabin_bar = 0.7; % Cabin pressurisation load (bar)
p_atmo = 0.1013; % Atmospheric pressure (MPa)
pressure_diff = cabin_alt_pressure - abs_ceil_pressure; % Pressure load due to cabin pressurisation
pressure_load = pressure_diff/(p_atmo*1e6)
t_f = 0.0028; % Fuselage skin thickness (m)
sigma_allow = 324; % Typical Allowable Stress (MPa)

sigma_h = (2*fuselage.R * cabin_bar * p_atmo)/(2*t_f) % Hoops stresses (Mpa)
sigma_l = (2*fuselage.R * cabin_bar * p_atmo)/(4*t_f) % Longitudinal stresses (Mpa)
sigma_d = (2*fuselage.R * cabin_bar * p_atmo)/(4*t_f) % Dome stresses (Mpa)


% Skin thickness constraints
t_req_manuf = 1; % Minimum Manufacturing thickness (mm)
t_req_shear = q_max/sigma_yield /1000 % Minimum skin thickness imposed by the shear flow (mm)
t_req_pressure = 1000*(2*fuselage.R*p_atmo*pressure_load)/(2*sigma_allow) % Skin thickenss imposed by pressure loads (mm)
tf_td =  (2-nu)/(1-nu) % Matched strains dome thickness ratio
t_dome =  t_req_pressure/tf_td % Dome thickness (mm)


%% Compute Buckling Coefficient (K) using ESDU Data
K_values = zeros(height(configs),1);
for i = 1:height(configs)
    K_values(i) = BucklingCoeff(configs.d_h_ratios(i), configs.td_ts_ratios(i), configs.ts_t_ratios(i), configs.h_b_ratios(i));
end
configs.K = K_values;
configs.axial_stress = N_load ./ (configs.t_skin * 1000);
configs(isnan(K_values), :) = []; % Remove invalid cases

%% Compute Buckling Stresses
configs.sigma_0 = 3.62 * E_modulus * 1e3 .* (configs.t_skin ./ configs.b_panel).^2;
configs.sigma_crZ = configs.K .* configs.sigma_0 ./ 3.62;

%% Compute Shear and 
configs.tau_cr = 5 * E_modulus * 1e3 .* (configs.t_skin ./ configs.b_panel) .^2;
configs.tau_max = q_max * 1e-3 ./ configs.t_skin;

%% Combined Loading effect on Buckling
configs.combined_buckling = (configs.axial_stress ./ configs.sigma_crZ) + (configs.tau_max ./ configs.tau_cr).^2;

%% Farrar Efficiency
% Consider flexural buckling mode
configs.As_bt_ratio = configs.A_stringer ./ (configs.b_panel .* configs.t_skin);

F = zeros(height(configs),1);
for i = 1:height(configs)
    F(i) = Farrar_new(configs.As_bt_ratio(i), configs.ts_t_ratios(i));
end
configs.Farrar = F;

% Remove invalid F & K*
idNoK = isnan(configs.K);%if failed to interpolate K
idNoFarrar = isnan(configs.Farrar);%if failed to interpolate Farrar
valid_configs = configs(~idNoK & ~idNoFarrar,:);
disp("Number of combinations after invalid K & Farrar were removed: " + height(configs));

%% Apply Structural Constraints
invalid_cases = unique([ ...
    find(valid_configs.axial_stress > sigma_yield);
    find(valid_configs.axial_stress > valid_configs.sigma_crZ);
    find(valid_configs.tau_max > valid_configs.tau_cr);
    find(valid_configs.combined_buckling >= 1)
]')
valid_configs(invalid_cases,:)=[];

disp("Valid Configurations After Structural Constraints: " + height(valid_configs));

%% Compute Light Frame Spacing
configs.L = (configs.Farrar ./ configs.sigma_crZ).^2 .* N_load .* Et_modulus * 1e3 * 1e-3;
valid_configs.L = (valid_configs.Farrar ./ valid_configs.sigma_crZ).^2 .* N_load .* Et_modulus * 1e3 * 1e-3;

%% Apply frame spacing constraints for windows
upper_frame_spacing_limit = valid_configs.L > 600; % Maximum 550mm
lower_frame_spacing_limit = valid_configs.L < 450;  % Minimum 450mm
valid_configs = valid_configs(~upper_frame_spacing_limit & ~lower_frame_spacing_limit, :);
disp("Configurations After Light Frame Spacing Constraints: " + height(valid_configs));

%% Determine number of frames
valid_configs.LframeNum = L_fuselage * 1000./ valid_configs.L;
valid_configs.LframeNum = ceil(valid_configs.LframeNum);

%% Compute Light Frame Inertia and Sizing
Cf = 0.0000625; % Empirical constant
valid_configs.LFi = (Cf * M_max * D_fuselage^2) ./ (valid_configs.L * 1e-3 * E_modulus * 1e9); % m^4
valid_configs.LFi = valid_configs.LFi * 1e12; % Convert to mm^4
valid_configs.LFi = round(valid_configs.LFi);

%% Determine combinations ofr Lifht Frame Profile (b,h,t)
bFrame = (20:0.2:80); % Frame width (mm)
hFrame = (20:0.2:80); % Frame height (mm)
tFrame = (1:0.01:10); % Frame thickness (mm)

frame_configs = combinations(bFrame, hFrame, tFrame);

% Ensure that height is always greater than width (C-section assumption)
frame_configs(frame_configs.bFrame > frame_configs.hFrame, :) = [];

% Comput moment of inertia for each frame configuration
frame_configs.inertia = (frame_configs.bFrame / 6) .* (frame_configs.tFrame .^ 3) + ...
    (((frame_configs.hFrame .^ 3) / 12) + (( frame_configs.hFrame .^ 2) / 2) .* frame_configs.bFrame) .* frame_configs.tFrame;
frame_configs.inertia = round(frame_configs.inertia);

%% Match Light Frames with Configurations
% Matches the computed required inertia (LFi) with the closes available
% frame configurations

valid_configs.LFmanufacturing = zeros(height(valid_configs),1); % Initialise manufacturing feasibility flag

% % Constrain stringer height to be less than the frame height
% valid_configs = valid_configs(valid_configs.h_str < valid_configs.hFrame, :);

for i = 1:height(valid_configs.LFi)
    idMatch = abs(frame_configs.inertia - valid_configs.LFi(i)) <= 5;
    frame_subset = frame_configs(idMatch, :);
    
    if ~isempty(frame_subset)
        % Compute frame area and select the minimum to reduce weight
        areaTemp = frame_subset.tFrame .* (2 * frame_subset.bFrame + frame_subset.hFrame);
        [~, k] = min(areaTemp);

        % Assign the optimal light frame properties
        valid_configs.bFrame(i) = frame_subset.bFrame(k);
        valid_configs.hFrame(i) = frame_subset.hFrame(k);
        valid_configs.tFrame(i) = frame_subset.tFrame(k);
        valid_configs.areaFrame(i) = min(areaTemp);

        % Indicate a feasible light frame was found
        valid_configs.LFmanufacturing(i) = 1;
    else
        % If no valid frame was found, mark as infeasible
        valid_configs.LFmanufacturing(i) = 0;
    end

end

% Remove configurations that are non manufacturable
valid_configs(find(valid_configs.LFmanufacturing == 0),:) =[];

%% Compute Mass of Skin, Stringers, and Frames
configs.skin_mass = pi * ((D_fuselage * 1e3 * configs.t_skin) - (configs.t_skin .^ 2)) * L_fuselage * rho_material * 1e-9 * 1e3;
valid_configs.skin_mass = pi * ((D_fuselage * 1e3 * valid_configs.t_skin) - (valid_configs.t_skin .^ 2)) * L_fuselage * rho_material * 1e-9 * 1e3;

configs.stringer_mass = configs.num_stringers .* ((configs.h_str .* configs.t_s) + (configs.d_str .* configs.t_d)) .* (L_fuselage * 1e3) * rho_material * 1e-9;
valid_configs.stringer_mass = valid_configs.num_stringers .*((valid_configs.h_str .* valid_configs.t_s) + (valid_configs.d_str .* valid_configs.t_d)) .*(L_fuselage * 1e3) * rho_material * 1e-9;

configs.frame_mass = configs.total_area .* C_fuselage .* configs.L * rho_material * 1e3 * 1e-9;
valid_configs.frame_mass = valid_configs.areaFrame .* C_fuselage .* valid_configs.L * rho_material * 1e3 * 1e-9;

valid_configs.total_mass = valid_configs.skin_mass + valid_configs.stringer_mass + valid_configs.frame_mass;
configs.total_mass = configs.skin_mass + configs.stringer_mass + configs.frame_mass;


%% Visualization of Feasible Configurations
figure; hold on;
grid on;
% scatter(configs.L / 1000, configs.total_mass, 10, [0.7,0.7,0.7], "filled", "o", "DisplayName", "Discarded");
scatter(valid_configs.L / 1000, valid_configs.total_mass, 10, 'g', "filled", "o", "DisplayName", "Feasible");
xlabel("Light Frame Spacing (m)", Fontsize = 15);
ylabel("Stringer-Skin Panel Weight (kg)", Fontsize = 15);
legend
% title("Fuselage Structural Optimization");
hold off;

[~, best_idx] = min(valid_configs.total_mass); 
best_config = valid_configs(best_idx, :);
% disp(best_config);

fprintf("Best Configuration:\n");
fprintf(" -----------------------");
fprintf(" - Skin-Stringers Panels");
fprintf(" -----------------------");
fprintf(" - Panel width: %.3f mm\n", best_config.b_panel);
fprintf(" - Stringer number: %.3f \n", floor((C_fuselage*1000)/best_config.b_panel));
fprintf(" - Stringer height: %.3f mm\n", best_config.h_str);
fprintf(" - Stringer flange width: %.3f mm\n", best_config.d_str);
fprintf(" - Stringer thickness: %.3f mm\n", best_config.t_s);
fprintf(" - Stringer flange thickness: %.3f mm\n", best_config.td_ts_ratios*best_config.t_s);
fprintf(" - Skin thickness: %.3f mm\n", best_config.t_skin);
fprintf(" -----------------------");
fprintf(" - Light Frame Panels");
fprintf(" -----------------------");
fprintf(" - Light Frame Number: %.3f \n", floor(L_fuselage*1000/best_config.L));
fprintf(" - Light Frame Spacing: %.3f mm\n", best_config.L);
fprintf(" - Light Frame Height: %.3f mm\n", best_config.hFrame);
fprintf(" - Light Frame Width: %.3f mm\n", best_config.bFrame);
fprintf(" - Light Frame Thickness: %.3f mm\n", best_config.tFrame);
fprintf(" - Light Frame Mass: %.3f kg\n", best_config.frame_mass);
fprintf(" - Total Mass: %.3f kg\n", best_config.total_mass);

