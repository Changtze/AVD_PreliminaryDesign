%% Heavy Frame Structural Analysis (Optimized for Actual Loads)
% This script determines the optimal dimensions for heavy frames by dynamically
% computing required area, moment of inertia, and bending moment resistance.

clear;
clc;

% Load required data files
load shear_bending.mat  % Contains shear forces and bending moments along fuselage
load loads_analysis_prelim.mat
load wing.mat
load tailplane.mat
load vertstab.mat
load place.mat
load fuselage.mat
load weights_all2.mat

% Define structural properties
sigmaYield = 430; % Yield stress, MPa
tauYield = sigmaYield / sqrt(3); % Shear yield stress, MPa
r_fuselage = fuselage.R; % fuselage radius (m)
c_fuselage = pi*2*r_fuselage; % fuselage circumference (m)
material_rho = 2765; % kg/m³

% Define manufacturing constraints
t = (1:0.1:30); % Thickness, mm
b = (20:0.5:150); % Flange width, mm
h = (30:0.5:100); % Web height, mm

% Create table containing all permutations
config = combinations(t,h,b);

%% Heavy Frame Locations (Key Structural Points)
wing_reaction_locations = place.move_wing_x + wing.main_spars_location * wing.wing_box_chord + wing.sweep_le * tand(fuselage.outer_diam / 2);
ht_reaction_locations = place.move_tail_x + tailplane.main_spars_location * tailplane.c_root;
vt_reaction_locations = place.move_vert_x + vertstab.main_spars_location * vertstab.c_root;

% Define frame names for clarity in the table
frame_names = {'Nose Gear', 'Midway Front', 'Midway Aft', 'Aft Bulkhead', ...
               'Wing Front Spar', 'Wing Rear Spar', ...
               'Tailplane Front Spar', 'Tailplane Rear Spar', ...
               'VertStab Front Spar', 'VertStab Rear Spar'};

locations = struct( ...
    'front_spar_wing', wing_reaction_locations(1), ...
    'aft_spar_wing', wing_reaction_locations(2), ...
    'front_spar_horz', ht_reaction_locations(1), ...
    'aft_spar_horz', ht_reaction_locations(2), ...
    'front_spar_vert', vt_reaction_locations(1), ...
    'aft_spar_vert', vt_reaction_locations(2), ...
    'front_centre', fuselage.nose.end_x, ...
    'aft_centre', fuselage.afterbody.start_x, ...
    'nose_gear_loc', weights2(14).x_cg, ...
    'front_midway', (wing_reaction_locations(1) + fuselage.nose.end_x) / 2, ...
    'aft_midway', (wing_reaction_locations(2) + fuselage.afterbody.start_x) / 2);

% Compute corresponding geometric properties
config.A = config.t .* (2 * config.b + config.h); % Area, mm^2
config.I = (config.b / 6) .* (config.t .^ 3) + (((config.h .^ 3) / 12) + ((config.h .^ 2) / 2) .* config.b) .* config.t; % Inertia, mm^4

%% Define frame locations
frame_locations = [locations.nose_gear_loc, locations.front_midway, locations.aft_midway, ...
                   locations.aft_centre, locations.front_spar_wing, locations.aft_spar_wing, ...
                   locations.front_spar_horz, locations.aft_spar_horz, ...
                   locations.front_spar_vert, locations.aft_spar_vert];

% Extract bending moments and shear forces at each frame location
casenum = 1; % VD at n = 3.75 load factor
moment_values = abs(s(casenum).BM_f);
shear_force_values = abs(s(casenum).SF_f);
moment_x = s(casenum).stations_fuselage;
shear_force_x = s(casenum).stations_fuselage;

bending_moments = interp1(moment_x, moment_values, frame_locations, 'linear', 'extrap');
shear_forces = interp1(shear_force_x, shear_force_values, frame_locations, 'linear', 'extrap');
tangential_forces = bending_moments ./ r_fuselage; 


% Compute required moment of inertia and area
minI = (bending_moments ./ sigmaYield) .* (h' / 2); % Moment of inertia requirement
minA_shear = shear_forces ./ tauYield; % Required area for shear load

%% Iterate through each frame location to determine optimal dimensions
optimized_frames = table();
for i = 1:length(frame_locations)
    frame_name = frame_names{i};
    x_frame = frame_locations(i);
    
    % Extract required values dynamically
    minA = minA_shear(i); % Required cross-sectional area based on shear force
    minI_req = minI(i); % Required moment of inertia
    
    % Apply filtering criteria
    valid_frames = config(config.A >= minA & config.I >= minI_req, :);
    
    % Further filtering for manufacturability
    valid_frames = valid_frames(valid_frames.t <= valid_frames.h / 2 & valid_frames.t <= valid_frames.b, :);

    % Select optimal frame with the lowest area
    [~, idx] = min(valid_frames.A);
    selected_frame = valid_frames(idx, :);

    % Calculate mass of selected frame
    selected_frame.M = selected_frame.A/1e6 * c_fuselage * material_rho;

    
    % Store results
    optimized_frames = [optimized_frames; {frame_name, x_frame, selected_frame.b, selected_frame.h, selected_frame.t, selected_frame.A, selected_frame.I, selected_frame.M}];
end

% Convert optimized results to table
optimized_frames.Properties.VariableNames = {'Frame','Location', 'Base_mm', 'Height_mm', 'Thickness_mm', 'Area_mm2', 'Ixx_mm4', 'Mass_kg'};

% Display results
disp(optimized_frames);

% Save results to CSV file
writetable(optimized_frames, 'Optimized_HeavyFrameResults.csv');
