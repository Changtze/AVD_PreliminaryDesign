function [name,component_stations,mass_at_stations] = mass_distribution_volume2(name,component_mass,mass_stations,volumes,distribution)

% Normalize volumes to obtain mass distribution
volume_sum = sum(volumes); % Integral of volume distribution
mass_density = (volumes / volume_sum) * component_mass; % Mass per segment

% Interpolate mass values at desired stations
component_stations =  mass_stations(mass_stations >= min(distribution) & mass_stations <= max(distribution));

if isempty(component_stations)
    mean_location = (min(distribution) + max(distribution))/2;
    [~,component_idx] = min(abs(mass_stations - mean_location));
    component_stations = mass_stations(component_idx);
else
end

mass_at_stations = interp1(distribution, mass_density, component_stations, 'linear', 'extrap');

% find remainder
remainder = sum(mass_at_stations) - component_mass;

% Compute the proportional distribution factor
proportions = mass_at_stations / sum(mass_at_stations); % Normalize elements

% Adjust mass at stations by distributing the remainder proportionally
mass_at_stations_new = mass_at_stations + (-1)*remainder * proportions;

mass_at_stations = mass_at_stations_new;
% % split remainder proportionally at end stations
% mass_at_stations([1,end]) = [mass_at_stations(1) + (-1)*remainder*(mass_at_stations(1)/(mass_at_stations(1) + mass_at_stations(end))),
%     mass_at_stations(end) + (-1)*remainder*(mass_at_stations(end)/(mass_at_stations(1) + mass_at_stations(end)))];

end